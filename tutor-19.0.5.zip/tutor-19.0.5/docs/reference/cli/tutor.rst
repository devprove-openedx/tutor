.. click:: tutor.commands.cli:cli
   :prog: tutor
   :nested: full
