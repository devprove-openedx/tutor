Command line interface (CLI)
============================

.. toctree::
   :maxdepth: 2

   tutor
   config
   dev
   images
   k8s
   local
   plugins
