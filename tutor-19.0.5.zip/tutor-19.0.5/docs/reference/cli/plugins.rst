.. _cli_plugins:

.. click:: tutor.commands.plugins:plugins_command
   :prog: tutor plugins
   :nested: full
