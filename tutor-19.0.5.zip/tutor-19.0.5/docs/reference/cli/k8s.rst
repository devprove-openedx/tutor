.. click:: tutor.commands.k8s:k8s
   :prog: tutor k8s
   :nested: full
