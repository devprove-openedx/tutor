---
name: Question about using Tutor
about: This is not the appropriate channel

---

Please post on our forums: https://discuss.openedx.org/tag/tutor for questions about using `tutor`.

Posts that are not a bug report or a feature/enhancement request will not be addressed on this issue tracker.
