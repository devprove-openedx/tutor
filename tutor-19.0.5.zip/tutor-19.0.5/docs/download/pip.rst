.. parsed-literal::

    pip install "tutor[full]"
