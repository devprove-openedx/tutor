.. _gettingstarted:

Getting started
===============

.. toctree::
   :maxdepth: 2

   install
   intro
   quickstart
   whatnext
