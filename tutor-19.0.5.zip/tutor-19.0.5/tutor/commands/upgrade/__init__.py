# Note: don't forget to change this when we upgrade from sumac
OPENEDX_RELEASE_NAMES = [
    "ironwood",
    "juniper",
    "koa",
    "lilac",
    "maple",
    "nutmeg",
    "olive",
    "palm",
    "quince",
    "redwood",
    "sumac",
]
