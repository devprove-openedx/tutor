.. click:: tutor.commands.images:images_command
   :prog: tutor images
   :nested: full
