from cms.envs.test import *

{% include "apps/openedx/settings/partials/common_test.py" %}
