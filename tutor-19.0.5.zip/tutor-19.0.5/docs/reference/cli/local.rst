.. click:: tutor.commands.local:local
   :prog: tutor local
   :nested: full
