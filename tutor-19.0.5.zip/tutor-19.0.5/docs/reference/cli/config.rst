.. click:: tutor.commands.config:config_command
   :prog: tutor config
   :nested: full
