User testimonials
-----------------

*"Tutor simplifies the deployment of Open edX, so that we can directly focus on customizing our platform. Thanks a lot."* -- Shashi Kiran G M

*"Tutor is an absolutely fabulous initiative"* -- Lionel Meinertzhagen, Learning engineer - `Université Libre de Bruxelles <https://www.ulb.be/>`__

*"Tutor just keeps on giving"* -- Stephen Brewer, Project Leader - IT Consulting

*"Tutor has been a Godsend"* -- Micah L.
