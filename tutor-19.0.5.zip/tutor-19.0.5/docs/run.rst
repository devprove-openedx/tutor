.. _run:

Running Open edX
================

.. toctree::
   :maxdepth: 2

   local
   k8s
   dev
