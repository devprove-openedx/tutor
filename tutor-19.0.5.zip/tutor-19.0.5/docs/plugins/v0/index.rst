=============
Legacy v0 API
=============

.. include:: legacy.rst

.. toctree::
   :maxdepth: 2

   api
   gettingstarted
