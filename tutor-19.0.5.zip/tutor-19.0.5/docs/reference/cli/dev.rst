.. click:: tutor.commands.dev:dev
   :prog: tutor dev
   :nested: full
